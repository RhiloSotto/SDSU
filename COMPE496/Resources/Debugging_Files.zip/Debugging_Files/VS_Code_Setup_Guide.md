# Visual Studio Code & Free IDE Setup Guide

## Quick Start Options

You have **3 FREE options** to use this debugging demo project:

1. **Visual Studio Code** (Cross-platform: Windows, Mac, Linux)
2. **Visual Studio Community Edition** (Windows only - Full-featured)
3. **Command Line + GDB/LLDB** (All platforms)

---

## Option 1: Visual Studio Code (Recommended for Cross-Platform)

### Prerequisites

#### All Platforms
- Download and install **Visual Studio Code**: https://code.visualstudio.com/

#### Windows
- Install **MSYS2** (includes g++): https://www.msys2.org/
  - Or install **MinGW-w64**: https://www.mingw-w64.org/
  - Or install **Visual Studio Build Tools**: https://visualstudio.microsoft.com/downloads/ (scroll down to "Tools for Visual Studio")

#### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install build-essential gdb cmake
```

#### Linux (Fedora/RHEL)
```bash
sudo dnf install gcc gcc-c++ gdb cmake
```

#### macOS
```bash
# Install Xcode Command Line Tools
xcode-select --install

# Or install via Homebrew
brew install cmake
```

### Setup Steps

1. **Open VS Code and Install Extensions**
   - Open Extensions panel (Ctrl+Shift+X or Cmd+Shift+X)
   - Install these extensions:
     - **C/C++** (by Microsoft) - Required
     - **C/C++ Extension Pack** (by Microsoft) - Recommended
     - **CMake Tools** (by Microsoft) - Recommended
     - **CMake** (by twxs) - Optional, for syntax highlighting

2. **Open the Project**
   - File → Open Folder
   - Select the folder containing `DebuggingDemo.cpp`
   - VS Code will detect the `.vscode` folder automatically

3. **Build the Project**
   - Press **Ctrl+Shift+B** (Cmd+Shift+B on Mac)
   - Select "Compile" from the task list
   - This will use CMake to build the project

4. **Start Debugging**
   - Open `DebuggingDemo.cpp`
   - Click in the left margin (next to line numbers) to set breakpoints
   - Press **F5** to start debugging
   - Select the appropriate configuration:
     - **(gdb) Launch** - for Linux/Windows with MinGW
     - **(lldb) Launch** - for macOS
     - **(Windows) Launch** - for Windows with MSVC

### VS Code Debugging Features

All the debugging features work similarly to Visual Studio:

| Feature | VS Code Action |
|---------|---------------|
| **Set Breakpoint** | Click in left margin or press F9 |
| **Start Debugging** | F5 |
| **Step Over** | F10 |
| **Step Into** | F11 |
| **Step Out** | Shift+F11 |
| **Continue** | F5 |
| **Stop** | Shift+F5 |
| **Watch Variables** | Right-click variable → Add to Watch |
| **View Call Stack** | Debug panel → Call Stack section |
| **View Threads** | Debug panel → expand to see threads |

### VS Code Debug Windows

When debugging (F5), the left sidebar shows:
- **Variables** - Local and global variables (like Locals window)
- **Watch** - Custom expressions you add (like Watch window)
- **Call Stack** - Function call hierarchy
- **Breakpoints** - List of all breakpoints
- **Debug Console** - Output and commands (like Immediate window)

---

## Option 2: Visual Studio Community Edition (Windows)

### Setup

1. **Download Visual Studio Community**
   - Go to: https://visualstudio.microsoft.com/vs/community/
   - Download the installer (FREE for students and individual developers)

2. **Install with C++ Workload**
   - Run the installer
   - Select **"Desktop development with C++"**
   - Click Install (requires ~7GB disk space)

3. **Open the Project**
   - Double-click `DebuggingDemo.sln`
   - Or File → Open → Project/Solution → Select `DebuggingDemo.sln`

4. **Build and Debug**
   - Press F5 to build and start debugging
   - All features from the original instructions work perfectly!

**This is the BEST option for Windows users** - you get all the professional debugging features mentioned in the lab.

---

## Option 3: Command Line Compilation (All Platforms)

### Direct Compilation (No IDE needed)

#### Linux/Mac
```bash
# Compile with debugging symbols
g++ -g -O0 -std=c++17 DebuggingDemo.cpp -o DebuggingDemo -lpthread

# Run the program
./DebuggingDemo

# Debug with GDB
gdb ./DebuggingDemo
```

#### Windows (with MinGW)
```bash
# Compile
g++ -g -O0 -std=c++17 DebuggingDemo.cpp -o DebuggingDemo.exe

# Run
DebuggingDemo.exe

# Debug with GDB
gdb DebuggingDemo.exe
```

### Using CMake (Recommended)

```bash
# Create build directory
mkdir build
cd build

# Configure
cmake ..

# Build
cmake --build . --config Debug

# Run (Linux/Mac)
./DebuggingDemo

# Run (Windows)
Debug\DebuggingDemo.exe
```

---

## GDB/LLDB Command Reference (For Command Line Debugging)

### Basic GDB Commands
```bash
# Start GDB
gdb ./DebuggingDemo

# Set breakpoint at main
(gdb) break main

# Set breakpoint at line 456
(gdb) break DebuggingDemo.cpp:456

# Set breakpoint in function
(gdb) break LinkedList::insert

# Run program
(gdb) run

# Step over (F10 equivalent)
(gdb) next

# Step into (F11 equivalent)
(gdb) step

# Continue (F5 equivalent)
(gdb) continue

# Print variable value
(gdb) print variableName

# Print all local variables
(gdb) info locals

# Show call stack
(gdb) backtrace
(gdb) bt

# View threads
(gdb) info threads

# Switch to thread
(gdb) thread 2

# Quit
(gdb) quit
```

### Basic LLDB Commands (macOS)
```bash
# Start LLDB
lldb ./DebuggingDemo

# Set breakpoint
(lldb) breakpoint set --name main
(lldb) b main

# Run
(lldb) run

# Step over
(lldb) next

# Step into
(lldb) step

# Continue
(lldb) continue

# Print variable
(lldb) print variableName

# View locals
(lldb) frame variable

# Call stack
(lldb) bt

# Quit
(lldb) quit
```

---

## Troubleshooting

### Issue: "CMake not found"
**Solution:**
- Windows: Install CMake from https://cmake.org/download/
- Linux: `sudo apt install cmake`
- Mac: `brew install cmake`

### Issue: "g++ command not found" (Windows)
**Solution:**
- Install MSYS2 or MinGW-w64
- Add to PATH: `C:\msys64\mingw64\bin`

### Issue: "Cannot find pthread" (Windows)
**Solution:**
- Remove `-lpthread` from compile command on Windows
- Or use Windows API for threads (code works as-is with MSVC)

### Issue: VS Code says "IntelliSense errors"
**Solution:**
- Press Ctrl+Shift+P (Cmd+Shift+P on Mac)
- Type "C/C++: Edit Configurations"
- Ensure compiler path is correct

### Issue: Breakpoints not hitting in VS Code
**Solution:**
- Ensure you're building with `-g` flag (debug symbols)
- Check that `CMAKE_BUILD_TYPE` is set to `Debug`
- Rebuild: `cmake --build build --config Debug --clean-first`

### Issue: "Thread debugging not working"
**Solution:**
- Linux: Install `gdb` if missing
- macOS: Code signing required for lldb, use `codesign` utility
- Or run without debugger to see output

---

## File Structure

```
DebuggingDemo/
├── DebuggingDemo.cpp          # Main source code
├── DebuggingDemo.sln          # Visual Studio solution (Windows)
├── DebuggingDemo.vcxproj      # Visual Studio project (Windows)
├── CMakeLists.txt             # CMake build file (cross-platform)
├── .vscode/                   # VS Code configuration
│   ├── tasks.json            # Build tasks
│   ├── launch.json           # Debug configurations
│   ├── c_cpp_properties.json # IntelliSense settings
│   ├── settings.json         # Workspace settings
│   └── extensions.json       # Recommended extensions
├── README.md                  # Original Visual Studio guide
├── VS_Code_README.md          # This file
├── Lab_Worksheet.md           # Student exercises
└── Instructor_Guide.md        # Teaching notes
```

---

## Debugging Feature Comparison

| Feature | VS Community | VS Code + GDB | Command Line GDB |
|---------|--------------|---------------|------------------|
| Breakpoints | ✅ Excellent | ✅ Excellent | ✅ Good |
| Step Operations | ✅ Excellent | ✅ Excellent | ✅ Good |
| Watch Variables | ✅ Excellent | ✅ Excellent | ✅ Manual |
| Call Stack | ✅ Visual | ✅ Visual | ✅ Text-based |
| Thread Debugging | ✅ Excellent | ✅ Good | ✅ Manual |
| Memory View | ✅ Excellent | ✅ Good | ✅ Manual |
| GUI | ✅ Full IDE | ✅ Editor | ❌ Command line |
| Cross-platform | ❌ Windows only | ✅ All platforms | ✅ All platforms |

---

## Recommended Setup by Platform

### Windows
**Best:** Visual Studio Community Edition (full features)  
**Alternative:** VS Code with MSVC or MinGW

### macOS
**Best:** VS Code with LLDB  
**Alternative:** Xcode (can import CMake projects)

### Linux
**Best:** VS Code with GDB  
**Alternative:** Command line GDB or CLion (paid)

---

## Learning Path Suggestions

### Beginners
1. Start with **Visual Studio Community** (Windows) or **VS Code** (other platforms)
2. Use GUI debugging features (breakpoints, watch windows)
3. Follow the exercises in `Lab_Worksheet.md`

### Intermediate
1. Try both GUI and command-line debugging
2. Learn GDB/LLDB commands
3. Explore advanced features (conditional breakpoints, data breakpoints)

### Advanced
1. Master command-line debugging
2. Use core dumps and post-mortem debugging
3. Learn remote debugging techniques

---

## Additional Resources

### VS Code Documentation
- C++ in VS Code: https://code.visualstudio.com/docs/languages/cpp
- Debugging: https://code.visualstudio.com/docs/editor/debugging

### GDB/LLDB
- GDB Tutorial: https://www.sourceware.org/gdb/documentation/
- LLDB Tutorial: https://lldb.llvm.org/use/tutorial.html
- GDB Cheat Sheet: https://darkdust.net/files/GDB%20Cheat%20Sheet.pdf

### CMake
- CMake Tutorial: https://cmake.org/cmake/help/latest/guide/tutorial/index.html

---

## Support

For issues specific to:
- **VS Code setup**: Check `.vscode` configuration files
- **Compilation errors**: Check compiler installation and PATH
- **Debugging issues**: Verify debug symbols are included (`-g` flag)
- **Lab exercises**: Refer to `Instructor_Guide.md`

---

**Happy Debugging! 🐛🔍**
