# Visual Studio Debugging Lab Worksheet
**Student Name:** ___________________________  **Date:** ___________

## Lab Objectives
By the end of this lab, you will be able to:
- Set and manage breakpoints effectively
- Navigate code using Step Over, Step Into, and Step Out
- Use Watch windows to monitor variables
- Understand call stacks and recursion
- Debug multi-threaded applications
- Inspect memory contents

---

## Part 1: Basic Breakpoint Operations (15 minutes)

### Exercise 1.1: Setting Your First Breakpoint
1. Open `DebuggingDemo.cpp` in Visual Studio
2. Locate the `main()` function (around line 450)
3. Set a breakpoint on the first executable line by clicking in the left margin
4. Press **F5** to start debugging

**Question 1:** What color is the breakpoint indicator?  
**Answer:** ___________________________

**Question 2:** What information appears in the tooltip when you hover over the breakpoint?  
**Answer:** ___________________________

### Exercise 1.2: Multiple Breakpoints
5. Set additional breakpoints at these locations:
   - Inside `LinkedList::insert()` (line ~65)
   - Inside `bubbleSort()` loop (line ~124)
   - Inside `threadWorker()` (line ~209)

6. Press **F5** to continue to the next breakpoint

**Question 3:** In what order do the breakpoints get hit? (Write line numbers)  
**Answer:** ___________________________

**Question 4:** How do you disable a breakpoint without deleting it?  
**Answer:** ___________________________

---

## Part 2: Step Operations (20 minutes)

### Exercise 2.1: Step Over vs Step Into
1. Set a breakpoint at `list.insert(10);` in `main()`
2. Start debugging (F5) and stop at this breakpoint
3. Press **F10** (Step Over)

**Question 5:** What happened? Did you enter the `insert()` function?  
**Answer:** ___________________________

4. Step back to `list.insert(20);`
5. This time press **F11** (Step Into)

**Question 6:** Where are you now? What line number?  
**Answer:** ___________________________

**Question 7:** Why would you use F10 instead of F11?  
**Answer:** ___________________________

### Exercise 2.2: Step Out
6. While inside the `insert()` function, press **Shift+F11** (Step Out)

**Question 8:** Where did you end up?  
**Answer:** ___________________________

**Task:** Practice these operations 5 more times until they feel natural.

---

## Part 3: Watch Windows (20 minutes)

### Exercise 3.1: Locals and Autos Windows
1. Set breakpoint inside `bubbleSort()` at the comparison line (line ~127)
2. Start debugging and hit the breakpoint
3. Open: Debug → Windows → Locals
4. Open: Debug → Windows → Autos

**Question 9:** List 3 variables shown in the Locals window:  
1. ___________________________  
2. ___________________________  
3. ___________________________

**Question 10:** How does Autos differ from Locals?  
**Answer:** ___________________________

### Exercise 3.2: Watch Window
5. Open: Debug → Windows → Watch → Watch 1
6. Manually add these expressions:
   - `arr[j]`
   - `arr[j+1]`
   - `swapped`
7. Press F10 several times to step through the loop

**Question 11:** Record the values as you step:

| Step | arr[j] | arr[j+1] | swapped |
|------|--------|----------|---------|
| 1    |        |          |         |
| 2    |        |          |         |
| 3    |        |          |         |

**Question 12:** Can you add complex expressions like `arr[j] > arr[j+1]` to Watch? Try it!  
**Answer:** ___________________________

---

## Part 4: Call Stack Navigation (20 minutes)

### Exercise 4.1: Understanding the Call Stack
1. Set breakpoint inside `quickSort()` (line ~161)
2. Start debugging and let it hit the breakpoint
3. Open: Debug → Windows → Call Stack

**Question 13:** How many stack frames are visible when first hitting the breakpoint?  
**Answer:** ___________________________

**Question 14:** What is the topmost function in the stack?  
**Answer:** ___________________________

### Exercise 4.2: Recursion and Stack Depth
4. Continue pressing F5 to let the recursive calls happen
5. Each time it breaks, check the Call Stack window

**Question 15:** What is the maximum number of stack frames you observed?  
**Answer:** ___________________________

**Question 16:** Double-click on different frames in the Call Stack. What happens?  
**Answer:** ___________________________

**Task:** Click on the `main()` frame in the stack. Note the values of local variables at that level.

**Question 17:** Can you see variables from `main()` while debugging is in `quickSort()`?  
**Answer:** ___________________________

---

## Part 5: Conditional Breakpoints (15 minutes)

### Exercise 5.1: Creating a Conditional Breakpoint
1. Set breakpoint in `LinkedList::search()` at line ~87
2. Right-click the breakpoint → Conditions
3. Select "Conditional Expression"
4. Enter: `value == 15`
5. Start debugging

**Question 18:** Does the breakpoint hit when searching for 10?  
**Answer:** ___________________________

**Question 19:** Does it hit when searching for 15?  
**Answer:** ___________________________

### Exercise 5.2: Hit Count Breakpoints
6. Set a breakpoint in the bubble sort inner loop (line ~127)
7. Right-click → Conditions → Hit Count
8. Set: "Break when hit count is equal to 5"

**Question 20:** How many times does the loop iterate before breaking?  
**Answer:** ___________________________

**Question 21:** Why are conditional breakpoints useful?  
**Answer:** ___________________________

---

## Part 6: Memory Window (15 minutes)

### Exercise 6.1: Viewing Memory
1. Set breakpoint in `MemoryDemo::demonstrateMemoryOperations()` (line ~240)
2. Step until `dynamicArray` is allocated and populated
3. Right-click `dynamicArray` → Add Watch
4. Note the memory address (e.g., 0x000001234567890)
5. Open: Debug → Windows → Memory → Memory 1
6. Paste the address

**Question 22:** Write the first 4 bytes you see in hexadecimal:  
**Answer:** ___________________________

**Question 23:** Can you identify the array values (0, 10, 20, 30, 40) in the memory?  
**Answer:** ___________________________

**Challenge:** Change the display format from hexadecimal to decimal. How do you do it?  
**Answer:** ___________________________

---

## Part 7: Thread Debugging (20 minutes)

### Exercise 7.1: Multiple Threads
1. Set breakpoint inside `threadWorker()` (line ~211 inside the loop)
2. Start debugging
3. When it breaks, open: Debug → Windows → Threads

**Question 24:** How many threads are listed?  
**Answer:** ___________________________

**Question 25:** Which thread is currently active? (Look for yellow arrow)  
**Answer:** ___________________________

### Exercise 7.2: Switching Between Threads
4. Double-click on a different thread in the Threads window
5. Look at the Locals window

**Question 26:** Does the `threadId` variable have different values in different threads?  
**Answer:** ___________________________

**Question 27:** What is the value of `sharedCounter` from different threads?  
**Answer:** ___________________________

### Exercise 7.3: Observing Synchronization
6. Press F5 to continue
7. Watch how threads take turns (mutex in action)

**Question 28:** Why do threads take turns instead of all updating simultaneously?  
**Answer:** ___________________________

---

## Part 8: Modifying Variables (10 minutes)

### Exercise 8.1: Runtime Variable Changes
1. Set breakpoint in bubble sort (line ~124)
2. When stopped, find the `swapped` variable in Locals
3. Double-click its value and change it to `true`
4. Continue execution

**Question 29:** What effect did changing `swapped` have on the algorithm?  
**Answer:** ___________________________

### Exercise 8.2: Array Modification
5. Expand the `arr` variable in Watch window
6. Change one of the array element values
7. Continue and observe the sorted output

**Question 30:** Can modifying variables during debugging help you test different scenarios?  
**Answer:** ___________________________

---

## Part 9: Practical Debugging Challenge (20 minutes)

### The Bug Hunt
Your instructor will add bugs to the code. Use debugging techniques to find them.

**Bug 1 Location:** ___________________________  
**What was wrong:** ___________________________  
**Debugging technique used:** ___________________________

**Bug 2 Location:** ___________________________  
**What was wrong:** ___________________________  
**Debugging technique used:** ___________________________

**Bug 3 Location:** ___________________________  
**What was wrong:** ___________________________  
**Debugging technique used:** ___________________________

---

## Part 10: Reflection (10 minutes)

**Question 31:** Which debugging feature did you find most useful? Why?  
**Answer:**  
___________________________  
___________________________  
___________________________

**Question 32:** What was the most challenging part of this lab?  
**Answer:**  
___________________________  
___________________________  
___________________________

**Question 33:** How will you use these debugging skills in your own projects?  
**Answer:**  
___________________________  
___________________________  
___________________________

**Question 34:** Rate your confidence with debugging (1-10): ___________

---

## Bonus Challenges (If Time Permits)

### Challenge 1: Data Breakpoints
- Set a data breakpoint on `sharedCounter`
- Determine which thread modifies it first

### Challenge 2: Parallel Stacks
- Open Parallel Stacks window during thread debugging
- Draw the visual representation you see

### Challenge 3: Disassembly
- Open the Disassembly window (Debug → Windows → Disassembly)
- Match C++ code to assembly instructions

---

## Instructor Sign-off

**Lab Completion:** ☐ Satisfactory  ☐ Needs Improvement

**Instructor Comments:**  
___________________________  
___________________________  
___________________________

**Instructor Signature:** ___________________________  **Date:** ___________

---

**Keyboard Shortcuts Quick Reference**

| Action | Shortcut |
|--------|----------|
| Start Debugging | F5 |
| Step Over | F10 |
| Step Into | F11 |
| Step Out | Shift+F11 |
| Toggle Breakpoint | F9 |
| Continue | F5 |
| Stop Debugging | Shift+F5 |

---

*Submit this completed worksheet to your instructor*
