# Instructor Guide: Visual Studio Debugging Techniques Lab

## Course Information
**Target Audience:** Computer Science students (CS2/Data Structures level)  
**Prerequisites:** Basic C++ knowledge, familiarity with Visual Studio IDE  
**Duration:** 2-3 hour lab session  
**Learning Management:** Lab worksheet provided for assessment

---

## Learning Objectives

By the end of this lab, students will be able to:

1. **Configure and use breakpoints** (basic, conditional, data breakpoints)
2. **Navigate code execution** using step operations (Over, Into, Out)
3. **Inspect program state** through Watch, Locals, and Autos windows
4. **Analyze call stacks** and understand function hierarchy
5. **Debug multi-threaded applications** using Threads window
6. **View raw memory** using Memory windows
7. **Modify variables** during runtime for testing scenarios
8. **Apply debugging strategies** to locate and fix bugs

---

## Pre-Lab Preparation

### For Instructors
1. ✓ Ensure all student computers have Visual Studio 2019+ installed
2. ✓ Test compile the project on lab machines
3. ✓ Verify Debug configuration is set (not Release)
4. ✓ Prepare "bugged" versions of code for Bug Hunt exercise
5. ✓ Print lab worksheets for students
6. ✓ Set up projector/screen for demonstrations

### For Students (Send beforehand)
- Install Visual Studio Community Edition if using personal laptops
- Download project files from course portal
- Review basic C++ concepts (pointers, loops, functions)

---

## Lesson Plan (2.5 hours)

### Introduction (15 minutes)
**Topics:**
- Importance of debugging skills in software development
- Overview of Visual Studio debugging features
- How debugging differs from using `cout` statements

**Activity:**
- Show live demo: Setting breakpoint and stepping through simple code
- Explain yellow arrow (current execution line) and red dots (breakpoints)

**Key Points to Emphasize:**
- Debugging is a skill that improves with practice
- Professional developers spend 50%+ of time debugging
- Tools make debugging systematic, not guesswork

---

### Part 1: Breakpoints and Step Operations (30 minutes)

**Demonstration (10 min):**
1. Open `DebuggingDemo.cpp` and set breakpoint in `main()`
2. Show F5 (Start), F10 (Step Over), F11 (Step Into)
3. Demonstrate yellow arrow following execution
4. Show how to toggle breakpoints with F9

**Guided Practice (15 min):**
- Students work on Lab Worksheet Part 1 & 2
- Circulate to answer questions
- Watch for common issues:
  - Running in Release mode (breakpoints won't work)
  - Confusion between F10 and F11
  - Not seeing breakpoint hit (wrong configuration)

**Assessment Check (5 min):**
- Ask students: "When would you use F11 vs F10?"
- Expected answer: F11 to see inside functions, F10 to stay at current level

**Common Student Questions:**
- Q: "My breakpoint has a hollow circle instead of solid red"
  - A: Code doesn't match compiled version; rebuild project
- Q: "Yellow arrow jumped over my code"
  - A: Code was optimized away; use Debug configuration

---

### Part 2: Watch Windows (25 minutes)

**Demonstration (10 min):**
1. Set breakpoint in `bubbleSort()` function
2. Show Autos window (automatic variables)
3. Show Locals window (all local variables)
4. Demonstrate adding expressions to Watch window
5. Show expanding objects (e.g., vector) to see contents

**Key Teaching Points:**
- Autos shows variables around current line (smart)
- Locals shows everything in scope (comprehensive)
- Watch is manual tracking (specific)
- Can add complex expressions to Watch

**Guided Practice (12 min):**
- Students complete Lab Worksheet Part 3
- Focus on watching `arr` values change during sort

**Challenge Activity (3 min):**
- "Add the expression `arr[j] > arr[j+1]` to Watch. What does it show?"
- Teaches that Watch can evaluate boolean expressions

**Common Confusion:**
- Students often don't expand objects in Watch
- Teach: Click triangle/plus to expand vectors, objects, pointers

---

### Part 3: Call Stack and Recursion (25 minutes)

**Demonstration (10 min):**
1. Set breakpoint in `quickSort()` recursive function
2. Show Call Stack window (Debug → Windows → Call Stack)
3. Step into recursive calls and watch stack grow
4. Click different stack frames to show local variables
5. Demonstrate Shift+F11 to step out

**Visual Aid:**
- Draw call stack on whiteboard/screen:
```
main()
  └─ quickSort(arr, 0, 6)
       └─ quickSort(arr, 0, 2)
            └─ quickSort(arr, 0, 1)  ← Currently here
```

**Guided Practice (12 min):**
- Students work on Lab Worksheet Part 4
- Have them record maximum recursion depth
- Emphasize: Each frame is a separate function call with own variables

**Discussion Questions (3 min):**
- "Why does recursion use more memory than iteration?"
- "What happens if recursion goes too deep?" (Stack overflow)

**Advanced Topic (if time):**
- Show how infinite recursion causes stack overflow
- Demonstrate in small example

---

### Part 4: Conditional Breakpoints (20 minutes)

**Demonstration (8 min):**
1. Set regular breakpoint in `LinkedList::search()` loop
2. Show annoyance of breaking every iteration
3. Right-click → Conditions
4. Add condition: `value == 15`
5. Show it only breaks when condition is true
6. Demonstrate Hit Count breakpoint: "break on 5th hit"

**Real-World Use Cases:**
- "Loop runs 10,000 times but bug only happens at item 5,000"
- "Function called many times but only fails with specific parameter"
- "Intermittent bug that occurs every 100th time"

**Guided Practice (10 min):**
- Students complete Lab Worksheet Part 5
- Have them experiment with different conditions

**Pro Tips to Share:**
- Can use complex expressions: `value > 100 && value < 200`
- Can reference member variables: `this->size > 10`
- Hit count useful for intermittent issues

**Assessment:**
- Ask students to explain when conditional breakpoints are necessary

---

### Part 5: Memory Window (20 minutes)

**Demonstration (10 min):**
1. Set breakpoint in `MemoryDemo::demonstrateMemoryOperations()`
2. Show stack variable allocation
3. Show heap allocation (`new`)
4. Open Memory window (Debug → Windows → Memory → Memory 1)
5. Show how to view address of variable
6. Point out hexadecimal bytes
7. Change display format (1-byte, 2-byte, 4-byte)

**Visual Explanation:**
Draw memory layout on board:
```
Stack:
  stackVar: [0x2A 0x00 0x00 0x00]  (42 in little-endian)

Heap:
  heapVar: [0x64 0x00 0x00 0x00]  (100 in little-endian)
  dynamicArray: [0x00 0x0A 0x14 0x1E 0x28]
```

**Guided Practice (8 min):**
- Students work through Lab Worksheet Part 6
- Help them find array values in memory

**Advanced Concept (if time):**
- Show how integers are stored in little-endian format
- Explain why bytes appear "backwards"

**Common Issues:**
- Students entering wrong address format
- Not understanding hexadecimal
- Solution: Show decimal-to-hex conversion

---

### Part 6: Thread Debugging (25 minutes)

**Demonstration (12 min):**
1. Explain multi-threading basics (show diagram)
2. Set breakpoint in `threadWorker()` function
3. Show Threads window when breakpoint hits
4. Demonstrate switching between threads
5. Show different thread IDs in Locals
6. Explain mutex and synchronization
7. Show Parallel Stacks window (if time)

**Key Concepts to Cover:**
- Each thread has own call stack
- Threads share memory (hence `sharedCounter`)
- Mutex prevents race conditions
- Yellow arrow shows current thread

**Guided Practice (10 min):**
- Students complete Lab Worksheet Part 7
- Focus on observing thread IDs and counter values

**Interactive Demo:**
- Ask: "What would happen without the mutex?"
- Comment out mutex lines and show race condition
- Uncomment to show fix

**Discussion (3 min):**
- "Why is multi-threading harder to debug?"
- "What are race conditions?"

---

### Part 7: Runtime Variable Modification (15 minutes)

**Demonstration (7 min):**
1. Set breakpoint in bubble sort
2. Show changing `swapped` variable value
3. Show changing array element values
4. Demonstrate effect on program execution

**Use Cases:**
- Testing edge cases without recompiling
- "What if this variable was 0 instead?"
- Forcing specific code paths

**Guided Practice (6 min):**
- Students work on Lab Worksheet Part 8
- Have them experiment with modifications

**Caution to Students:**
- Changes are temporary (not saved to code)
- Can cause unexpected behavior if misused
- Good for testing, not fixing

**Challenge:**
- "Can you force the bubble sort to exit early by modifying variables?"

---

### Part 8: Bug Hunt Challenge (30 minutes)

**Preparation:**
Create bugged versions of code with common errors:

**Bug 1: Off-by-One Error**
```cpp
// In bubbleSort, change:
for (int j = 0; j < n - i - 1; j++)
// To:
for (int j = 0; j <= n - i - 1; j++)  // Will access out of bounds!
```

**Bug 2: Pointer Issue**
```cpp
// In LinkedList::insert(), comment out:
// newNode->next = nullptr;  // Forgot to initialize!
```

**Bug 3: Logic Error**
```cpp
// In search function, change:
if (current->data == value) return true;
// To:
if (current->data == value) return false;  // Inverted logic!
```

**Activity Instructions:**
1. Distribute bugged code version to students
2. Students use debugging techniques to find bugs
3. Record findings on worksheet
4. Discuss solutions as a class

**Debrief Questions:**
- Which debugging technique helped you find each bug?
- Could you have found these with `cout` statements?
- How much faster was debugging vs. trial and error?

---

## Assessment Rubric

### Lab Worksheet Grading (100 points)

| Component | Points | Criteria |
|-----------|--------|----------|
| **Completion** | 30 | All sections attempted |
| **Accuracy** | 30 | Correct answers to questions |
| **Bug Hunt** | 20 | Successfully found and explained bugs |
| **Reflection** | 10 | Thoughtful responses |
| **Technique Application** | 10 | Used appropriate debugging methods |

### Grading Guidelines

**A (90-100):**
- All questions answered correctly
- Found all bugs with proper explanations
- Demonstrated mastery of debugging techniques
- Insightful reflections

**B (80-89):**
- Most questions correct
- Found 2 of 3 bugs
- Good understanding of core concepts
- Some minor errors in application

**C (70-79):**
- Partial completion
- Found 1-2 bugs
- Basic understanding demonstrated
- Needs more practice

**D (60-69):**
- Incomplete work
- Struggled to find bugs
- Limited understanding
- Requires remediation

---

## Common Student Struggles & Solutions

### Struggle 1: "I can't find the bug!"
**Solution:**
- Guide through systematic approach:
  1. Reproduce the error
  2. Set breakpoint before error occurs
  3. Step through and watch variables
  4. Identify line where values become wrong
- Teach: Debugging is detective work, not guessing

### Struggle 2: "Too many windows, I'm overwhelmed"
**Solution:**
- Start with just Locals window
- Add Watch window only when needed
- Gradually introduce other windows
- Show: Window → Reset Window Layout

### Struggle 3: "Breakpoint not hitting"
**Solution Checklist:**
- ☐ Is project built in Debug mode?
- ☐ Is breakpoint enabled (solid red)?
- ☐ Is code path actually executed?
- ☐ Try Clean → Rebuild

### Struggle 4: "Variables show 'optimized away'"
**Solution:**
- Check: Debug configuration selected
- Options → Debugging → Suppress JIT optimization
- Explain: Compiler removes unused code

### Struggle 5: "Thread debugging is confusing"
**Solution:**
- Draw thread timeline on board
- Use colors to represent different threads
- Show one thread at a time first
- Gradually introduce concurrent viewing

---

## Extension Activities

### For Advanced Students

**1. Data Breakpoint Challenge**
- Set data breakpoint on `sharedCounter`
- Identify which thread modifies it in what order

**2. Memory Forensics**
- Given memory dump, identify data structure
- Reverse engineer object layout

**3. Performance Profiling**
- Use Performance Profiler (Debug → Performance Profiler)
- Identify bottlenecks in sorting algorithms

**4. Custom Debug Visualizers**
- Create natvis file for custom linked list visualization
- Research: natvis XML format

### For Struggling Students

**1. Simplified Bug Hunt**
- Provide code with single, obvious bug
- Guide step-by-step through debugging process

**2. Debugging Flashcards**
- Create cards with debugging scenarios
- Match scenario to appropriate technique

**3. Pair Debugging**
- Partner strong and weak students
- Driver/Navigator model for bug hunting

---

## Additional Resources

### For Students
- Visual Studio Debugging Tips (video): [Link]
- Keyboard shortcuts cheat sheet: Provided separately
- Practice problems: Available on course website

### For Instructors
- Sample exam questions: See `exam_questions.md`
- Debugging case studies: See `case_studies/`
- Additional bugged code samples: See `bugs/`

---

## FAQ - Instructor Edition

**Q: How much time should students spend on each section?**
A: Times are guidelines. Adjust based on class pace. Core sections are 1-4.

**Q: Should I cover all debugging features in one session?**
A: No. Focus on breakpoints, stepping, and watch windows first. Advanced features (memory, threads) can be second session.

**Q: What if students' Visual Studio looks different?**
A: Window locations may vary. Teach: "Debug → Windows → [feature name]"

**Q: Can this lab be done remotely?**
A: Yes, with screen sharing. Consider shorter session or async components.

**Q: How do I handle mixed skill levels?**
A: Provide extension activities for advanced students. Offer simplified bugs for strugglers.

**Q: Is the threading section too advanced?**
A: It can be. Mark as optional or save for later course.

---

## Learning Outcomes Mapping

### Course Outcomes Supported
- **CO1: Problem Solving** - Systematic debugging approach
- **CO2: Tool Proficiency** - IDE mastery
- **CO3: Code Analysis** - Understanding execution flow
- **CO4: Algorithm Understanding** - Tracing algorithm execution

### Skills Developed
- **Technical Skills:**
  - Visual Studio proficiency
  - Debugging methodology
  - Code tracing
  - Memory management awareness

- **Soft Skills:**
  - Patience and persistence
  - Analytical thinking
  - Attention to detail
  - Problem-solving strategies

---

## Post-Lab Assessment

### Quiz Questions (for next class)

1. What keyboard shortcut steps over a function call?
2. When would you use a conditional breakpoint?
3. Name the window that shows all local variables.
4. How do you view the contents of raw memory?
5. What does each frame in the Call Stack represent?

### Programming Assignment

**Assignment:** "Debug Hunt"
- Provide students with intentionally bugged program
- Must use debugging techniques (not just guessing)
- Submit screenshot evidence of debugging process
- Write report explaining techniques used

---

## Continuous Improvement

### Collect Feedback On:
- Were instructions clear?
- Was time allocation appropriate?
- Which sections were most valuable?
- Which sections could be cut if short on time?
- What additional topics would be helpful?

### Update Checklist:
- ☐ Review student worksheet responses
- ☐ Note common errors for next iteration
- ☐ Adjust time allocations based on pacing
- ☐ Update bug examples if too easy/hard
- ☐ Incorporate student suggestions

---

**Version:** 1.0  
**Last Updated:** 2024  
**Contact:** [Your contact information]  
**Course:** CS XXX - Data Structures and Algorithms
