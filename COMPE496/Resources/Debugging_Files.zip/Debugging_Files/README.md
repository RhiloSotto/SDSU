# Visual Studio C++ Debugging Techniques Demo

## Project Overview
This is a comprehensive educational project designed to teach college students Visual Studio debugging techniques through practical algorithms and data structures implementations.

## Features Demonstrated

### 1. **Data Structures**
- Linked List with pointer manipulation
- Binary Search Tree with recursive operations
- Graph representation with adjacency lists

### 2. **Algorithms**
- Bubble Sort (iterative)
- Quick Sort (recursive)
- Breadth-First Search (BFS)

### 3. **Debugging Techniques**
- ✓ Breakpoints (regular, conditional, data breakpoints)
- ✓ Call Stack navigation
- ✓ Step Over (F10), Step Into (F11), Step Out (Shift+F11)
- ✓ Watch windows (Autos, Locals, Watch)
- ✓ Memory window inspection
- ✓ Thread debugging
- ✓ Variable inspection and modification

## Getting Started

### Prerequisites
- Visual Studio 2019 or later (Community Edition is fine)
- Windows OS
- C++17 support enabled

### Opening the Project
1. Double-click `DebuggingDemo.vcxproj` to open in Visual Studio
2. Or: File → Open → Project/Solution → Select `DebuggingDemo.vcxproj`
3. Build the project: Build → Build Solution (Ctrl+Shift+B)

## Debugging Exercises

### Exercise 1: Basic Breakpoints
**Goal:** Learn to set and manage breakpoints

1. Open `DebuggingDemo.cpp`
2. Set a breakpoint at line ~450 (first line in `main()`) by:
   - Clicking in the left margin, OR
   - Pressing F9 on that line
3. Start debugging: Debug → Start Debugging (F5)
4. Program will pause at the breakpoint
5. Use Continue (F5) to proceed to next breakpoint

**Key Concepts:**
- Red dot indicates active breakpoint
- F9 toggles breakpoints on/off
- Ctrl+Shift+F9 removes all breakpoints

---

### Exercise 2: Step Operations
**Goal:** Control execution flow precisely

1. Set breakpoint at `list.insert(10);` (line ~456)
2. Start debugging (F5)
3. When stopped at breakpoint:
   - Press **F10 (Step Over)**: Executes the line without entering the function
   - Notice how the line executes and moves to next line
4. At `list.insert(20);`:
   - Press **F11 (Step Into)**: Enters the insert function
   - Step through the function line by line with F10
   - Press **Shift+F11 (Step Out)**: Returns to caller

**Key Concepts:**
- F10 = Step Over (execute without debugging into functions)
- F11 = Step Into (debug inside function calls)
- Shift+F11 = Step Out (finish current function)

---

### Exercise 3: Watch Windows
**Goal:** Monitor variable values during execution

1. Set breakpoint inside `LinkedList::insert()` loop (line ~72)
2. Start debugging and wait to hit breakpoint
3. Open watch windows:
   - Debug → Windows → Autos (shows relevant variables)
   - Debug → Windows → Locals (shows all local variables)
   - Debug → Windows → Watch → Watch 1
4. In Watch window, manually add:
   - `current`
   - `current->data`
   - `size`
5. Step through (F10) and watch values change

**Key Concepts:**
- Autos: Automatically shows relevant variables
- Locals: Shows all variables in current scope
- Watch: Manually track specific variables/expressions
- Can expand objects to see members

---

### Exercise 4: Call Stack
**Goal:** Understand function call hierarchy and recursion

1. Set breakpoint inside `quickSort()` function (line ~161)
2. Start debugging and let it hit the breakpoint
3. Open Call Stack: Debug → Windows → Call Stack
4. Observe the stack frames:
   - Current function on top
   - Caller functions below
   - Each recursive call adds a new frame
5. Click different stack frames to see local variables at each level

**Key Concepts:**
- Call stack shows execution path
- Great for understanding recursion depth
- Click frames to inspect variables at different levels
- Return addresses shown for each frame

---

### Exercise 5: Conditional Breakpoints
**Goal:** Break only when specific conditions are met

1. Set breakpoint in `LinkedList::search()` loop (line ~87)
2. Right-click the breakpoint → Conditions
3. Select "Conditional Expression"
4. Enter condition: `value == 15`
5. Click Close
6. Start debugging
7. Breakpoint will only trigger when searching for 15

**Advanced:**
- Try "Hit Count" condition: "Break when hit count is equal to 3"
- Try "Filter" for specific thread IDs

**Key Concepts:**
- Conditional breakpoints reduce noise
- Useful for loops with many iterations
- Can combine multiple conditions

---

### Exercise 6: Memory Window
**Goal:** View raw memory contents

1. Set breakpoint in `MemoryDemo::demonstrateMemoryOperations()` at line ~235
2. Start debugging and hit the breakpoint
3. Step over until `dynamicArray` is created and populated
4. Right-click `dynamicArray` variable → Add Watch
5. In Watch window, note the address value
6. Open Memory window: Debug → Windows → Memory → Memory 1
7. Paste the address into the Address field
8. Watch the memory contents (hexadecimal values)
9. Step through array population and see bytes change

**Key Concepts:**
- Memory windows show raw byte values
- Useful for debugging buffer issues
- Can see memory layout of structures
- 4 memory windows available simultaneously

---

### Exercise 7: Thread Debugging
**Goal:** Debug multi-threaded applications

1. Set breakpoint inside `threadWorker()` function (line ~209)
2. Start debugging
3. When breakpoint hits, open: Debug → Windows → Threads
4. Observe multiple threads in the list
5. Note which thread is currently active (yellow arrow)
6. Switch between threads by double-clicking
7. Notice each thread has different local variable values
8. Watch the Call Stack change for each thread

**Advanced:**
- Right-click thread → Freeze (pause that thread)
- Right-click thread → Thaw (resume that thread)
- Use Parallel Stacks: Debug → Windows → Parallel Stacks

**Key Concepts:**
- Each thread has its own call stack
- Threads window shows all active threads
- Can freeze/thaw threads to control execution
- Watch mutex locks in action

---

### Exercise 8: Data Breakpoints
**Goal:** Break when memory changes (address-based)

1. Run program in debug mode
2. Break at any point in `main()`
3. Right-click variable `sharedCounter` → Break When Value Changes
4. Continue execution (F5)
5. Debugger will stop whenever `sharedCounter` is modified
6. Check which thread/function changed it

**Note:** Data breakpoints are hardware-limited (usually 4 maximum)

**Key Concepts:**
- Tracks memory address, not variable name
- Useful for finding unexpected modifications
- Works across functions and threads
- Hardware-assisted debugging

---

### Exercise 9: Modifying Values During Debug
**Goal:** Change variable values while debugging

1. Set breakpoint in bubble sort (line ~124)
2. When stopped, find `arr` in Locals or Watch
3. Expand the vector to see elements
4. Double-click a value to edit it
5. Continue execution and see how it affects sorting

**Try This:**
- Set `swapped = true` manually
- Change array values mid-sort
- Modify loop counters (be careful!)

**Key Concepts:**
- Can modify any variable during debugging
- Useful for testing different scenarios
- Can force code paths by changing conditions

---

### Exercise 10: Advanced - Parallel Stacks
**Goal:** Visualize multi-threaded execution

1. Set breakpoint in `threadWorker()` (line ~209)
2. Start debugging and let all threads hit breakpoints
3. Open: Debug → Windows → Parallel Stacks
4. See visual representation of all thread call stacks
5. Hover over boxes to see thread details
6. Switch between Method View and Tasks View

**Key Concepts:**
- Visual representation of concurrent execution
- Shows which threads are at same location
- Great for understanding thread synchronization

---

## Debugging Window Reference

| Window | Shortcut | Purpose |
|--------|----------|---------|
| Autos | Ctrl+Alt+V, A | Shows variables used around current line |
| Locals | Ctrl+Alt+V, L | Shows all variables in current scope |
| Watch 1-4 | Ctrl+Alt+W, 1-4 | Manually tracked variables |
| Call Stack | Ctrl+Alt+C | Function call hierarchy |
| Threads | Ctrl+Alt+H | All active threads |
| Memory 1-4 | Ctrl+Alt+M, 1-4 | Raw memory view |
| Disassembly | Ctrl+Alt+D | Assembly code view |
| Registers | Ctrl+Alt+G | CPU register values |

## Keyboard Shortcuts

| Action | Shortcut | Description |
|--------|----------|-------------|
| Start Debugging | F5 | Begin debugging session |
| Step Over | F10 | Execute line, don't enter functions |
| Step Into | F11 | Enter function calls |
| Step Out | Shift+F11 | Finish current function |
| Toggle Breakpoint | F9 | Add/remove breakpoint |
| Continue | F5 | Resume execution |
| Stop Debugging | Shift+F5 | End debug session |
| Run to Cursor | Ctrl+F10 | Execute until cursor position |

## Common Issues and Solutions

### Issue: "Cannot find or open the PDB file"
**Solution:** Build the project in Debug mode (not Release)

### Issue: Breakpoints not hitting
**Solution:** 
- Ensure you're running in Debug mode
- Check breakpoint is not disabled (should be solid red)
- Verify code hasn't been optimized out

### Issue: Variables show "optimized away"
**Solution:** 
- Build in Debug configuration
- Debug → Options → Optimization → Suppress JIT optimization

### Issue: Threads window empty
**Solution:** Break execution while threads are running (not at program start)

## Tips for Students

1. **Start Simple:** Begin with basic breakpoints before advanced features
2. **Practice Stepping:** Master F10 and F11 early - most important skills
3. **Use Watch Liberally:** Don't be afraid to add expressions to watch
4. **Explore Call Stack:** Click different frames to understand program flow
5. **Read Tooltips:** Hover over variables for quick values
6. **Save Layouts:** Window → Save Window Layout (for your preferred debug setup)

## Additional Resources

- Visual Studio Debugging Documentation: https://docs.microsoft.com/visualstudio/debugger/
- Keyboard shortcuts: Help → Keyboard Shortcut Reference
- Debug settings: Debug → Options → Debugging

## Assignment Ideas

1. **Find the Bug:** Introduce bugs and have students use debugging to find them
2. **Algorithm Trace:** Use breakpoints to trace sorting algorithm step-by-step
3. **Recursion Depth:** Measure maximum call stack depth in recursive functions
4. **Race Condition:** Remove mutex and observe threading issues
5. **Memory Leaks:** Add leaks and use debugging to find them

## License
Educational use - feel free to modify and distribute for teaching purposes.

---

**Created for educational purposes to teach Visual Studio debugging techniques**
