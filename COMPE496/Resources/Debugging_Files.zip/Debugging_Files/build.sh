#!/bin/bash
# Build script for DebuggingDemo (Linux/macOS)

echo "============================================"
echo "DebuggingDemo Build Script"
echo "============================================"
echo

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check for C++ compiler
if command -v g++ &> /dev/null; then
    COMPILER="g++"
    echo -e "${GREEN}Found: g++ compiler${NC}"
elif command -v clang++ &> /dev/null; then
    COMPILER="clang++"
    echo -e "${GREEN}Found: clang++ compiler${NC}"
else
    echo -e "${RED}ERROR: No C++ compiler found!${NC}"
    echo
    echo "Please install one:"
    echo "  Ubuntu/Debian: sudo apt install build-essential"
    echo "  Fedora/RHEL:   sudo dnf install gcc-c++"
    echo "  macOS:         xcode-select --install"
    exit 1
fi

# Compile
echo "Building with $COMPILER..."
$COMPILER -std=c++17 -g -O0 -Wall -Wextra DebuggingDemo.cpp -o DebuggingDemo -lpthread

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo
    echo -e "${GREEN}============================================${NC}"
    echo -e "${GREEN}Build successful!${NC}"
    echo -e "${GREEN}============================================${NC}"
    echo
    echo "Executable: ./DebuggingDemo"
    echo
    echo "Usage:"
    echo "  Run:   ./DebuggingDemo"
    
    # Check which debugger is available
    if command -v gdb &> /dev/null; then
        echo "  Debug: gdb ./DebuggingDemo"
    elif command -v lldb &> /dev/null; then
        echo "  Debug: lldb ./DebuggingDemo"
    fi
    
    echo
    echo "Quick start debugging:"
    echo "  1. gdb ./DebuggingDemo"
    echo "  2. (gdb) break main"
    echo "  3. (gdb) run"
    echo "  4. (gdb) next     # Step over"
    echo "  5. (gdb) step     # Step into"
    exit 0
else
    echo
    echo -e "${RED}============================================${NC}"
    echo -e "${RED}Build failed!${NC}"
    echo -e "${RED}============================================${NC}"
    exit 1
fi
