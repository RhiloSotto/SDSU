@echo off
REM Windows Batch Script for Building DebuggingDemo
REM Works with MinGW/MSYS2 or Visual Studio Developer Command Prompt

echo ============================================
echo DebuggingDemo Build Script for Windows
echo ============================================
echo.

REM Check if g++ is available (MinGW/MSYS2)
where g++ >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo Found: g++ compiler (MinGW/MSYS2)
    echo Building with g++...
    g++ -std=c++17 -g -O0 -Wall DebuggingDemo.cpp -o DebuggingDemo.exe
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo ============================================
        echo Build successful!
        echo Executable: DebuggingDemo.exe
        echo ============================================
        echo.
        echo Run with: DebuggingDemo.exe
        echo Debug with: gdb DebuggingDemo.exe
        goto end
    ) else (
        echo Build failed!
        goto end
    )
)

REM Check if cl.exe is available (Visual Studio)
where cl >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo Found: cl compiler (Visual Studio)
    echo Building with MSVC...
    cl /EHsc /Zi /std:c++17 /Fe:DebuggingDemo.exe DebuggingDemo.cpp
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo ============================================
        echo Build successful!
        echo Executable: DebuggingDemo.exe
        echo ============================================
        echo.
        echo Run with: DebuggingDemo.exe
        goto end
    ) else (
        echo Build failed!
        goto end
    )
)

REM No compiler found
echo ============================================
echo ERROR: No C++ compiler found!
echo ============================================
echo.
echo Please install one of the following:
echo.
echo 1. MinGW/MSYS2:
echo    https://www.msys2.org/
echo.
echo 2. Visual Studio Build Tools:
echo    https://visualstudio.microsoft.com/downloads/
echo    (Scroll to "Tools for Visual Studio")
echo.
echo 3. Visual Studio Community:
echo    https://visualstudio.microsoft.com/vs/community/
echo.

:end
pause
