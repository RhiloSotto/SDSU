/*
 * Visual Studio C++ Debugging Techniques Demo
 * Project: Algorithm and Data Structures with Debugging Showcase
 * 
 * This project demonstrates:
 * - Breakpoint usage
 * - Call stack navigation
 * - Step Over (F10) and Step Into (F11)
 * - Watch windows and variable inspection
 * - Memory viewing
 * - Thread debugging
 * - Conditional breakpoints
 */

#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <algorithm>
#include <chrono>
#include <memory>

using namespace std;

// ==================== SECTION 1: Basic Data Structures ====================
// DEBUGGING TIP: Set breakpoints at constructors to watch object creation

class Node {
public:
    int data;
    Node* next;
    
    Node(int val) : data(val), next(nullptr) {
        // BREAKPOINT HERE: Watch 'this' pointer and member initialization
        cout << "Node created with value: " << data << endl;
    }
    
    ~Node() {
        cout << "Node destroyed with value: " << data << endl;
    }
};

class LinkedList {
private:
    Node* head;
    int size;
    
public:
    LinkedList() : head(nullptr), size(0) {
        // BREAKPOINT HERE: Watch constructor execution
        cout << "LinkedList initialized" << endl;
    }
    
    ~LinkedList() {
        clear();
    }
    
    // DEBUGGING TIP: Set breakpoint inside loop to watch iteration
    void insert(int value) {
        Node* newNode = new Node(value); // BREAKPOINT: Watch memory allocation
        
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* current = head;
            // BREAKPOINT IN LOOP: Use Step Over to traverse list
            while (current->next != nullptr) {
                current = current->next; // Watch 'current' pointer change
            }
            current->next = newNode;
        }
        size++;
        // BREAKPOINT HERE: Inspect 'size' in Watch window
    }
    
    // DEBUGGING TIP: Step Into this function to follow the search logic
    bool search(int value) {
        Node* current = head;
        int position = 0;
        
        // CONDITIONAL BREAKPOINT: Right-click → Conditions → "value == 15"
        while (current != nullptr) {
            if (current->data == value) {
                cout << "Found " << value << " at position " << position << endl;
                return true; // BREAKPOINT: Check call stack here
            }
            current = current->next;
            position++;
        }
        return false;
    }
    
    void display() {
        Node* current = head;
        cout << "List contents: ";
        // BREAKPOINT: Watch 'current' change in Locals window
        while (current != nullptr) {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }
    
    void clear() {
        Node* current = head;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp; // BREAKPOINT: Watch memory deallocation in Memory window
        }
        head = nullptr;
        size = 0;
    }
    
    int getSize() const { return size; }
};

// ==================== SECTION 2: Sorting Algorithms ====================
// DEBUGGING TIP: Use Step Over to see algorithm progress iteration by iteration

class SortingDemo {
public:
    // Bubble Sort with detailed debugging opportunities
    static void bubbleSort(vector<int>& arr) {
        int n = arr.size();
        cout << "\n=== Starting Bubble Sort ===" << endl;
        
        // BREAKPOINT: Set at outer loop to watch passes
        for (int i = 0; i < n - 1; i++) {
            bool swapped = false;
            cout << "Pass " << (i + 1) << ": ";
            
            // BREAKPOINT: Set at inner loop to watch comparisons
            for (int j = 0; j < n - i - 1; j++) {
                // CONDITIONAL BREAKPOINT: "arr[j] > arr[j+1]" to break only on swaps
                if (arr[j] > arr[j + 1]) {
                    swap(arr[j], arr[j + 1]); // BREAKPOINT: Watch values change
                    swapped = true;
                }
            }
            
            // BREAKPOINT: Add arr to Watch window to see array state
            displayVector(arr);
            
            if (!swapped) {
                cout << "Array is sorted! Early termination." << endl;
                break; // BREAKPOINT: Understand early exit optimization
            }
        }
    }
    
    // Quick Sort with recursion - excellent for call stack demonstration
    static void quickSort(vector<int>& arr, int low, int high) {
        // BREAKPOINT: Watch call stack grow with each recursive call
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            
            cout << "Pivot at index " << pivotIndex << " with value " << arr[pivotIndex] << endl;
            displayVector(arr);
            
            // BREAKPOINT: Step Into to follow left recursion, Step Over to skip
            quickSort(arr, low, pivotIndex - 1);  // Left subarray
            quickSort(arr, pivotIndex + 1, high); // Right subarray
        }
    }
    
private:
    static int partition(vector<int>& arr, int low, int high) {
        int pivot = arr[high]; // BREAKPOINT: Watch pivot selection
        int i = low - 1;
        
        // BREAKPOINT: Watch partitioning process
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                swap(arr[i], arr[j]); // Watch swaps in Autos window
            }
        }
        swap(arr[i + 1], arr[high]);
        return i + 1; // BREAKPOINT: Check return value
    }
    
public:
    static void displayVector(const vector<int>& arr) {
        for (int num : arr) {
            cout << num << " ";
        }
        cout << endl;
    }
};

// ==================== SECTION 3: Binary Search Tree ====================
// DEBUGGING TIP: Great for watching recursive calls and pointer manipulation

class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;
    
    TreeNode(int val) : data(val), left(nullptr), right(nullptr) {
        // BREAKPOINT: Watch tree node creation
        cout << "TreeNode created: " << data << endl;
    }
};

class BinarySearchTree {
private:
    TreeNode* root;
    
    // Recursive insert - watch call stack!
    TreeNode* insertHelper(TreeNode* node, int value) {
        // BREAKPOINT: Watch recursion depth in Call Stack window
        if (node == nullptr) {
            return new TreeNode(value); // BREAKPOINT: Watch new node creation
        }
        
        // BREAKPOINT: Use Step Into to follow recursion path
        if (value < node->data) {
            node->left = insertHelper(node->left, value);
        } else if (value > node->data) {
            node->right = insertHelper(node->right, value);
        }
        
        return node;
    }
    
    // Inorder traversal - watch recursion pattern
    void inorderHelper(TreeNode* node) {
        if (node == nullptr) return;
        
        // BREAKPOINT: Watch Call Stack to see recursion pattern
        inorderHelper(node->left);    // Step Into to go left
        cout << node->data << " ";    // Visit node
        inorderHelper(node->right);   // Step Into to go right
    }
    
    // Tree height calculation
    int heightHelper(TreeNode* node) {
        if (node == nullptr) return 0;
        
        // BREAKPOINT: Watch left and right heights being computed
        int leftHeight = heightHelper(node->left);
        int rightHeight = heightHelper(node->right);
        
        // BREAKPOINT: Add expression "leftHeight > rightHeight ? leftHeight : rightHeight" to Watch
        return max(leftHeight, rightHeight) + 1;
    }
    
public:
    BinarySearchTree() : root(nullptr) {}
    
    void insert(int value) {
        root = insertHelper(root, value);
    }
    
    void inorderTraversal() {
        cout << "Inorder Traversal: ";
        inorderHelper(root);
        cout << endl;
    }
    
    int height() {
        return heightHelper(root);
    }
};

// ==================== SECTION 4: Multi-Threading Demo ====================
// DEBUGGING TIP: Use Threads window (Debug → Windows → Threads) during execution

mutex mtx;
int sharedCounter = 0;

// Worker function for thread demonstration
void threadWorker(int threadId, int iterations) {
    // BREAKPOINT: Watch different threads hit this breakpoint
    // Check thread ID in Threads window (Debug → Windows → Threads)
    
    for (int i = 0; i < iterations; i++) {
        // BREAKPOINT: Only this thread's breakpoint will show its threadId value
        mtx.lock(); // Watch thread synchronization
        
        sharedCounter++; // BREAKPOINT: Watch race condition prevention
        cout << "Thread " << threadId << " incremented counter to " << sharedCounter << endl;
        
        mtx.unlock();
        
        // Simulate some work
        this_thread::sleep_for(chrono::milliseconds(10));
    }
    
    // BREAKPOINT: Check Call Stack to see thread entry point
    cout << "Thread " << threadId << " finished" << endl;
}

// ==================== SECTION 5: Memory Management Demo ====================
// DEBUGGING TIP: Use Memory windows (Debug → Windows → Memory)

class MemoryDemo {
public:
    static void demonstrateMemoryOperations() {
        cout << "\n=== Memory Operations Demo ===" << endl;
        
        // Stack allocation
        int stackVar = 42; // BREAKPOINT: Right-click → Add to Watch
        cout << "Stack variable address: " << &stackVar << endl;
        
        // Heap allocation
        int* heapVar = new int(100); // BREAKPOINT: Open Memory window, enter &heapVar
        cout << "Heap variable address: " << heapVar << endl;
        cout << "Heap variable value: " << *heapVar << endl;
        
        // Array allocation
        int* dynamicArray = new int[5]; // BREAKPOINT: View array in Memory window
        for (int i = 0; i < 5; i++) {
            dynamicArray[i] = i * 10; // BREAKPOINT: Watch array being populated
        }
        
        // BREAKPOINT: Right-click dynamicArray → Add Watch → expand to see all elements
        cout << "Dynamic array contents: ";
        for (int i = 0; i < 5; i++) {
            cout << dynamicArray[i] << " ";
        }
        cout << endl;
        
        // DEBUGGING TIP: Before deleting, copy address from Memory window
        delete heapVar;          // BREAKPOINT: Watch memory being freed
        delete[] dynamicArray;   // BREAKPOINT: Array deletion
        
        // Smart pointer demo
        unique_ptr<int> smartPtr = make_unique<int>(200);
        // BREAKPOINT: Inspect smartPtr in Watch window to see internal pointer
        cout << "Smart pointer value: " << *smartPtr << endl;
        
    } // BREAKPOINT: Watch smart pointer automatic cleanup at scope end
};

// ==================== SECTION 6: Graph Algorithm ====================
// Breadth-First Search with detailed debugging

class Graph {
private:
    int vertices;
    vector<vector<int>> adjacencyList;
    
public:
    Graph(int v) : vertices(v) {
        adjacencyList.resize(v);
        cout << "Graph created with " << v << " vertices" << endl;
    }
    
    void addEdge(int u, int v) {
        adjacencyList[u].push_back(v);
        adjacencyList[v].push_back(u); // Undirected graph
        // BREAKPOINT: Watch adjacency list being built
    }
    
    void BFS(int startVertex) {
        cout << "\n=== Breadth-First Search starting from vertex " << startVertex << " ===" << endl;
        
        vector<bool> visited(vertices, false);
        queue<int> q;
        
        visited[startVertex] = true; // BREAKPOINT: Watch visited array
        q.push(startVertex);
        
        // BREAKPOINT: Watch queue contents in Watch window (expand q)
        while (!q.empty()) {
            int current = q.front();
            q.pop();
            cout << "Visiting vertex: " << current << endl;
            
            // BREAKPOINT: Step through neighbors processing
            for (int neighbor : adjacencyList[current]) {
                // CONDITIONAL BREAKPOINT: "!visited[neighbor]"
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                    // BREAKPOINT: Watch queue grow with new vertices
                }
            }
        }
    }
    
    void display() {
        cout << "\nGraph Adjacency List:" << endl;
        for (int i = 0; i < vertices; i++) {
            cout << "Vertex " << i << ": ";
            for (int neighbor : adjacencyList[i]) {
                cout << neighbor << " ";
            }
            cout << endl;
        }
    }
};

// ==================== MAIN FUNCTION ====================
// DEBUGGING TIP: Set breakpoint at start and use Step Over to control demo flow

int main() {
    cout << "=====================================" << endl;
    cout << "Visual Studio Debugging Techniques Demo" << endl;
    cout << "=====================================" << endl;
    
    // BREAKPOINT: Start here and use F10 (Step Over) to control execution
    
    // === Demo 1: Linked List ===
    cout << "\n--- Demo 1: Linked List Operations ---" << endl;
    LinkedList list;
    
    // BREAKPOINT: Step Into (F11) insert to see implementation
    list.insert(10);
    list.insert(20);
    list.insert(30);
    list.insert(15);
    list.display();
    
    // BREAKPOINT: Step Into to follow search logic
    list.search(15);
    list.search(99);
    
    // === Demo 2: Sorting Algorithms ===
    cout << "\n--- Demo 2: Sorting Algorithms ---" << endl;
    vector<int> arr1 = {64, 34, 25, 12, 22, 11, 90};
    cout << "Original array: ";
    SortingDemo::displayVector(arr1);
    
    // BREAKPOINT: Step Into to watch bubble sort iterations
    SortingDemo::bubbleSort(arr1);
    cout << "After Bubble Sort: ";
    SortingDemo::displayVector(arr1);
    
    vector<int> arr2 = {38, 27, 43, 3, 9, 82, 10};
    cout << "\nOriginal array: ";
    SortingDemo::displayVector(arr2);
    
    // BREAKPOINT: Watch Call Stack grow with recursion
    SortingDemo::quickSort(arr2, 0, arr2.size() - 1);
    cout << "After Quick Sort: ";
    SortingDemo::displayVector(arr2);
    
    // === Demo 3: Binary Search Tree ===
    cout << "\n--- Demo 3: Binary Search Tree ---" << endl;
    BinarySearchTree bst;
    
    // BREAKPOINT: Watch tree structure being built
    vector<int> treeValues = {50, 30, 70, 20, 40, 60, 80};
    for (int val : treeValues) {
        bst.insert(val); // Step Into to follow recursive insertion
    }
    
    bst.inorderTraversal();
    cout << "Tree height: " << bst.height() << endl;
    
    // === Demo 4: Multi-Threading ===
    cout << "\n--- Demo 4: Multi-Threading ---" << endl;
    cout << "Starting 3 threads..." << endl;
    
    // BREAKPOINT: Use Threads window (Debug → Windows → Threads) during execution
    vector<thread> threads;
    for (int i = 1; i <= 3; i++) {
        threads.push_back(thread(threadWorker, i, 5));
    }
    
    // BREAKPOINT: Watch all threads complete
    for (auto& t : threads) {
        t.join(); // Wait for all threads to finish
    }
    cout << "Final counter value: " << sharedCounter << endl;
    
    // === Demo 5: Memory Operations ===
    // BREAKPOINT: Open Memory window before entering this function
    MemoryDemo::demonstrateMemoryOperations();
    
    // === Demo 6: Graph BFS ===
    cout << "\n--- Demo 6: Graph Breadth-First Search ---" << endl;
    Graph g(6);
    
    // Building a simple graph
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.addEdge(2, 4);
    g.addEdge(3, 5);
    g.addEdge(4, 5);
    
    g.display();
    
    // BREAKPOINT: Watch BFS exploration pattern
    g.BFS(0);
    
    cout << "\n=====================================" << endl;
    cout << "Demo Complete!" << endl;
    cout << "=====================================" << endl;
    
    // BREAKPOINT: Set here to inspect final state before exit
    return 0;
}

/*
 * =====================================================================
 * DEBUGGING EXERCISES FOR STUDENTS
 * =====================================================================
 * 
 * 1. BREAKPOINTS BASICS
 *    - Set breakpoint at main() first line
 *    - Use F5 to run, F10 to step over, F11 to step into
 *    - Practice toggling breakpoints (F9)
 * 
 * 2. WATCH WINDOWS
 *    - Add variables to Watch window during linked list insertion
 *    - Watch 'arr' during sorting to see values change
 *    - Monitor 'sharedCounter' during thread execution
 * 
 * 3. CALL STACK
 *    - Set breakpoint inside quickSort recursion
 *    - Examine Call Stack window to see recursion depth
 *    - Click different stack frames to see local variables
 * 
 * 4. CONDITIONAL BREAKPOINTS
 *    - Right-click breakpoint → Conditions
 *    - Set condition: "value == 15" in search function
 *    - Set hit count: break only on 3rd iteration
 * 
 * 5. MEMORY WINDOW
 *    - Debug → Windows → Memory → Memory 1
 *    - Copy variable address (e.g., &stackVar)
 *    - Paste in Memory window to see raw bytes
 *    - Watch memory change during array operations
 * 
 * 6. THREADS WINDOW
 *    - Debug → Windows → Threads
 *    - Set breakpoint in threadWorker
 *    - Switch between threads to see different local values
 *    - Freeze/thaw threads to control execution
 * 
 * 7. AUTOS & LOCALS
 *    - Debug → Windows → Autos (shows relevant variables)
 *    - Debug → Windows → Locals (shows all local variables)
 *    - Compare what appears in each window
 * 
 * 8. STEP OPERATIONS
 *    - F10 (Step Over): Execute current line, don't enter functions
 *    - F11 (Step Into): Enter function calls to debug inside
 *    - Shift+F11 (Step Out): Finish current function and return
 * 
 * 9. DATA BREAKPOINTS
 *    - Right-click variable → Break When Value Changes
 *    - Useful for finding where memory is modified
 * 
 * 10. PARALLEL STACKS
 *     - Debug → Windows → Parallel Stacks (during threading)
 *     - Visual representation of all thread call stacks
 * 
 * =====================================================================
 */
